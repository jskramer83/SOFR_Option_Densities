
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OBJECTIVE: Import SOFR futures and option prices and convert them into
%            risk-neutral state price densities.
%            Interpolation of the implied volatility surface is done using
%            the SABR model while the calibration of a continuous probability 
%            density function is done using a skewed-t distribution for
%            consistency with the growth-at-risk model.
%
% REFERENCES:
% - Figlewski and Gao (1999) - The adaptive mesh model: a new approach to
%    efficient option pricing
%    https://www.sciencedirect.com/science/article/pii/S0304405X99000240
% - Breeden & Litzenberg (1978) - Prices of State-Contingent Claims Implicit in Option Prices
%    https://www.jstor.org/stable/2352653
% - Malz (2014) - A Simple and Reliable Way to Compute Option-Based Risk-Neutral Distributions
%    https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr677.pdf
% - Hagan et al (2002) - Managing Smile Risk
%    https://www.deriscope.com/docs/Hagan_2002.pdf
% - Adrian et al (2019) - Vulnerable Growth
%    https://www.aeaweb.org/articles?id=10.1257/aer.20161923
%
% NOTES        
%             To run the tool:
%             - change to desired import dates in line 42
%             - change plot observation dates correspondingly in lines 413 and 421
%             - change for plotting to desired tenors in lines 414 and 422
%             - manually change current Fed Funds rate and Fed dots
%               corresponding to tenor in lines 433 and 434
%             To note:
%             - Bloomberg import override 'OPT_FUTURES_CHAIN_DATES' does
%               not retroactively change to the future chains that are
%               valid at a given point in time. This is an error on BBG's
%               side and raised in helpdesk tickets H#1282743756,
%               H#1282743756 and H#1280352941, reply pending.
%             - Because of that, it is recommended to not choose
%               observation dates too distant in the past, which is also
%               why continuous time-series functionality is for now not
%               supported. 
%             - Instead, pick a few discrete observation dates, e.g. around
%               Fed decisions or important macro releases
%             - For now, only tested on SOFR options, expansion into other
%               listed derivatives is work in progress.
% AUTHORS     Johannes S Kramer
% DATE        05/07/2024
% VERSION     0.1
% Written in MATLAB2023b
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Import data
clc
clear all
close all
makedist -reset 

% Add Bloomberg Java Path
javaaddpath c:\blp\DAPI\blpapi3.jar

%% Initialise Bloomberg API
param.c = blp;
param.c.DatetimeType = 'datetime';
param.c.DataReturnFormat = 'table';

%% Define some input parameters
param.Datevec = [datetime('30/04/2024','InputFormat','dd/MM/yyyy');datetime('06/05/2024','InputFormat','dd/MM/yyyy')];
param.nDates = size(param.Datevec,1);
param.CurveTicker = {'YCSW0490 Index'};% Ticker of the risk free curve
param.UnderlyingTicker = 'SFRA Comdty';% Ticker of the underlying futures
param.incr = 0.005;
param.minOpenInt = 2000;
param.PutCallFlagOffset = 6;% Within 1st columnn of jnk, put call flag is sixth letter
param.StrikeCol = 4;% Column within split option ticker string where the strikes a stored

OutTbl = table();

%% A. Iterate over times
for t = 1:param.nDates
   
    % Create datestring of observation date for Bloomberg API query
    t_.DateStr = datestr(param.Datevec(t),'yyyymmdd');

    %% 1. Get the term structure of futures contracts at a given point in time    
    % t_.FuturesContracts = getdata(param.c, param.UnderlyingTicker,'FUT_CHAIN',{'Chain_Date'},t_.DateStr);
    t_.FuturesContracts = getdata(param.c, param.UnderlyingTicker,'OPT_FUTURES_CHAIN_DATES',{'Chain_Date'},t_.DateStr);
    % t_.FuturesContracts = getdata(param.c, param.UnderlyingTicker,'OPT_CHAIN',{'Chain_Date'},t_.DateStr);
    t_.FuturesContracts = t_.FuturesContracts.OPT_FUTURES_CHAIN_DATES{1,1};% Flatten output

    % Only keep the last quarterly contracts
    t_.idxWithinQ = [diff(quarter(t_.FuturesContracts.UnderlyingMaturity));1] == 0;
    t_.FuturesContracts(t_.idxWithinQ,:) = [];

    
    t_.nFutures = size(t_.FuturesContracts,1);
    t_.FuturesContracts.Options = cell(t_.nFutures,1);    
    t_.FuturesContracts.UnderlyingContract = cellfun(@(x) [x ' Comdty'],t_.FuturesContracts.UnderlyingContract,'UniformOutput',false);    

    % Calculate time to maturity of each contract
    t_.FuturesContracts.ttm = days(t_.FuturesContracts.OptionExpiration - param.Datevec(t))./360; % time to maturity    


    %% 2.Pull the futures prices
    if param.Datevec(t) == datetime('today')
        t_.FuturesPrices = getdata(param.c, t_.FuturesContracts.UnderlyingContract,{'PX_LAST','OPEN_INT'});
        % Re-format realtime data so it's similar to the historical output
        tmp_.tbl = cell(t_.nFutures,1);
        for i = 1:t_.nFutures
            tmp_.tbl(i) = {[table(param.Datevec(t),'VariableNames',{'DATE'}) ...
                            table(t_.FuturesPrices.PX_LAST(i),'VariableNames',{'PX_LAST'}) ...
                            table(t_.FuturesPrices.OPEN_INT(i),'VariableNames',{'OPEN_INT'})]};            
        end
        t_.FuturesPrices = tmp_.tbl;            
        clear tmp_
    else
        t_.FuturesPrices = history(param.c, t_.FuturesContracts.UnderlyingContract,{'PX_LAST','OPEN_INT'},param.Datevec(t),param.Datevec(t));        
    end
    


    % Filter out options without price and open interest
    t_.EmptyFuturesPriceIdx = cellfun(@(x) isempty(x),t_.FuturesPrices,'UniformOutput',false);
    t_.EmptyFuturesPriceIdx = [t_.EmptyFuturesPriceIdx{:}]';        
    t_.FuturesPrices = t_.FuturesPrices(~t_.EmptyFuturesPriceIdx,:);
    t_.FuturesContracts = t_.FuturesContracts(~t_.EmptyFuturesPriceIdx,:);

    % Assign the futures price
    t_.FuturesContracts.Fwd_PX = cellfun(@(x) x.PX_LAST,t_.FuturesPrices,'UniformOutput',false);
    t_.FuturesContracts.Fwd_PX = [t_.FuturesContracts.Fwd_PX{:}]';

    % Assign the futures open interest
    t_.FuturesContracts.OPEN_INT = cellfun(@(x) x.OPEN_INT,t_.FuturesPrices,'UniformOutput',false);
    t_.FuturesContracts.OPEN_INT = [t_.FuturesContracts.OPEN_INT{:}]';


    %% 3. Pull the corresponding yield curve to map tenor-matched risk-free rates
    t_.Curve = getbulkdata(param.c, param.CurveTicker, 'CURVE_TENOR_RATES', {'CURVE_DATE'},t_.DateStr);
    t_.Curve = t_.Curve.CURVE_TENOR_RATES{1,1}  ;% Flatten output
    t_.Curve.tau = TenorsToTau(t_.Curve.Tenor)';      
    
    % Interpolate discount rate so it corresponds to the time to maturity per contract
    t_.FuturesContracts.r_f = interp1(t_.Curve.tau,t_.Curve.MidYield,t_.FuturesContracts.ttm,'linear')./100;


    %% B. iterate over futures tenors
    for i = 1:t_.nFutures

        % Import all option contracts linked to the futures contract
        t_.OptionsContracts = getdata(param.c, t_.FuturesContracts.UnderlyingContract(i),'OPT_CHAIN',{'Chain_Date'},t_.DateStr);
        t_.OptionsContracts = t_.OptionsContracts.OPT_CHAIN{1,1};% Flatten output
        t_.OptionsContracts.Properties.VariableNames{1} = 'OptionTickers';

        % Format the option price table
        t_.jnk = split(t_.OptionsContracts.OptionTickers,' ');

        % Match the underlying futures prices
        t_.UnderlyingTicker = cellfun(@(x) x(1:(param.PutCallFlagOffset-1)),t_.jnk(:,1),'UniformOutput',false);
        t_.FutTicker = split(t_.FuturesContracts.UnderlyingContract(i),' ');
        t_.FutTicker = t_.FutTicker(1);
        t_.IdxOpt = ismember(t_.UnderlyingTicker,t_.FutTicker);
        t_.OptionsContracts = t_.OptionsContracts(t_.IdxOpt,:);

        % Format the option price table
        t_.jnk = split(t_.OptionsContracts.OptionTickers,' ');


        % Extract put/call flag        
        t_.OptionsContracts.PutCall = cellfun(@(x) x(param.PutCallFlagOffset),t_.jnk(:,1),'UniformOutput',false);
        t_.nOptions = size(t_.OptionsContracts,1);

        

        % Extract strike price
        t_.OptionsContracts.Strike = cellfun(@(x) str2num(x),t_.jnk(:,param.StrikeCol),'UniformOutput',false);
        t_.OptionsContracts.Strike = [t_.OptionsContracts.Strike{:}]';

        % Get Bloomberg option prices and open interest
        if param.Datevec(t) == datetime('today')
            t_.OptionPrices = getdata(param.c, t_.OptionsContracts.OptionTickers,{'PX_LAST','OPEN_INT'});
            % Re-format realtime data so it's similar to the historical output
            tmp_.tbl = cell(t_.nOptions,1);
            for j = 1:t_.nOptions
                tmp_.tbl(j) = {[table(param.Datevec(t),'VariableNames',{'DATE'}) ...
                                table(t_.OptionPrices.PX_LAST(j),'VariableNames',{'PX_LAST'}) ...
                                table(t_.OptionPrices.OPEN_INT(j),'VariableNames',{'OPEN_INT'})]};
            end
            t_.OptionPrices = tmp_.tbl;
            clear tmp_
        else
            t_.OptionPrices = history(param.c, t_.OptionsContracts.OptionTickers,{'PX_LAST','OPEN_INT'},param.Datevec(t),param.Datevec(t));
        end
            
        % Filter out options without price and open interest
        t_.EmptyOptionPriceIdx = cellfun(@(x) isempty(x),t_.OptionPrices,'UniformOutput',false);
        t_.EmptyOptionPriceIdx = [t_.EmptyOptionPriceIdx{:}]';        
        t_.OptionPrices = t_.OptionPrices(~t_.EmptyOptionPriceIdx,:);
        t_.OptionsContracts = t_.OptionsContracts(~t_.EmptyOptionPriceIdx,:);
        
        % Assign the option price
        t_.OptionsContracts.Option_PX = cellfun(@(x) x.PX_LAST,t_.OptionPrices,'UniformOutput',false);
        t_.OptionsContracts.Option_PX = [t_.OptionsContracts.Option_PX{:}]';

        % Assign the option open interest
        t_.OptionsContracts.OPEN_INT = cellfun(@(x) x.OPEN_INT,t_.OptionPrices,'UniformOutput',false);
        t_.OptionsContracts.OPEN_INT = [t_.OptionsContracts.OPEN_INT{:}]';

        % Store option contract pricing information
        t_.FuturesContracts.Options(i) = {t_.OptionsContracts};        
    end

    t_.OutTbl = [table(param.Datevec(t),'VariableNames',{'Date'}) table({t_.FuturesContracts},'VariableNames',{'Data'})];

    OutTbl = [OutTbl;t_.OutTbl];
    clear t_

end

OutTbl_raw = OutTbl;
OutTbl = OutTbl_raw;


%%  Now, clean the price data
for t = 1:param.nDates

    nFutures = size(OutTbl.Data{t},1);
    OutTbl.Data{t}.Options_clean = cell(nFutures,1);    
    OutTbl.Data{t}.Fwd_implied = NaN(nFutures,1);
    OutTbl.Data{t}.r_f_implied = NaN(nFutures,1);

    for i = 1:nFutures
         
        % Calculate implied volatility for calls
        t_.CallIdx = ismember(OutTbl.Data{t}.Options{i}.PutCall,{'C'});
        t_.C_K = OutTbl.Data{t}.Options{i}.Strike(t_.CallIdx);
        t_.C_p = OutTbl.Data{t}.Options{i}.Option_PX(t_.CallIdx);
        t_.nC = size(t_.C_p,1);
        t_.Fwd = repmat(OutTbl.Data{t}.Fwd_PX(i),t_.nC,1);
        t_.tau = repmat(OutTbl.Data{t}.ttm(i),t_.nC,1);
        t_.r_f = repmat(OutTbl.Data{t}.r_f(i),t_.nC,1);                     
        t_.C_iv = blkimpv(t_.Fwd, t_.C_K, t_.r_f, t_.tau, t_.C_p,[],[],{'call'});

        C_tbl = [OutTbl.Data{t}.Options{i}(t_.CallIdx,'PutCall') ...
                    array2table([t_.C_K t_.C_iv],'VariableNames',{'Strike','ImpliedVol'})];
        clear t_
        
        % Calculate implied volatility for puts
        t_.PutIdx = ismember(OutTbl.Data{t}.Options{i}.PutCall,{'P'});
        t_.P_K = OutTbl.Data{t}.Options{i}.Strike(t_.PutIdx);
        t_.P_p = OutTbl.Data{t}.Options{i}.Option_PX(t_.PutIdx);
        t_.nP = size(t_.P_p,1);
        t_.Fwd = repmat(OutTbl.Data{t}.Fwd_PX(i),t_.nP,1);
        t_.tau = repmat(OutTbl.Data{t}.ttm(i),t_.nP,1);
        t_.r_f = repmat(OutTbl.Data{t}.r_f(i),t_.nP,1);                     
        t_.P_iv = blkimpv(t_.Fwd, t_.P_K, t_.r_f, t_.tau, t_.P_p,[],[],{'put'});

        P_tbl = [OutTbl.Data{t}.Options{i}(t_.PutIdx,'PutCall') ...
                    array2table([t_.P_K t_.P_iv],'VariableNames',{'Strike','ImpliedVol'})];

        clear t_
        
        IV_tbl = [C_tbl;P_tbl];
        IV_tbl = unique(IV_tbl);
        clear C_tbl P_tbl

        % Join back the calculated implied volatilities
        OutTbl.Data{t}.Options{i} = join(OutTbl.Data{t}.Options{i},IV_tbl,"Keys",{'PutCall','Strike'},"RightVariables","ImpliedVol");

        clear IV_tbl
                
        t_.IV = unstack(OutTbl.Data{t}.Options{i}(:,{'Strike','PutCall','ImpliedVol'}),'ImpliedVol','PutCall');
        t_.OpenInt = unstack(OutTbl.Data{t}.Options{i}(:,{'Strike','PutCall','OPEN_INT'}),'OPEN_INT','PutCall');
        t_.Prices = unstack(OutTbl.Data{t}.Options{i}(:,{'Strike','PutCall','Option_PX'}),'Option_PX','PutCall');


        % Overwrite option contracts with less than a minimum no. of open interest with NaNs
        t_.smallIdxC = t_.OpenInt.C>=param.minOpenInt;
        t_.IV.C(~t_.smallIdxC) = NaN;
        t_.OpenInt.C(~t_.smallIdxC) = NaN;
        t_.Prices.C(~t_.smallIdxC) = NaN;
        t_.smallIdxP = t_.OpenInt.P>=param.minOpenInt;
        t_.IV.P(~t_.smallIdxP) = NaN;
        t_.OpenInt.P(~t_.smallIdxP) = NaN;               
        t_.Prices.P(~t_.smallIdxC) = NaN;
        
   

        % Iterate through puts and calls to calculate averages of implied vols depending on open interest
        t_.nStrikes = size(t_.IV,1);
        t_.CleanIV = zeros(t_.nStrikes,4);
        for k = 1 : t_.nStrikes

          if isnan(t_.OpenInt.P(k)) && isnan(t_.OpenInt.C(k))
            t_.CleanIV(k,:) = [t_.IV.Strike(k) NaN NaN NaN];

          elseif isnan(t_.OpenInt.P(k)) && ~isnan(t_.OpenInt.C(k))
            t_.CleanIV(k,:) = [t_.IV.Strike(k) t_.IV.C(k) NaN t_.OpenInt.C(k)];

          elseif ~isnan(t_.OpenInt.P(k)) && isnan(t_.OpenInt.C(k))
            t_.CleanIV(k,:) = [t_.IV.Strike(k) t_.IV.P(k) NaN t_.OpenInt.P(k)];

          elseif ~isnan(t_.OpenInt.P(k)) && ~isnan(t_.OpenInt.C(k))
            t_.CleanIV(k,:) = [t_.IV.Strike(k) (t_.IV.C(k)+t_.IV.P(k))/2 (t_.IV.C(k)-t_.IV.P(k)) t_.OpenInt.C(k) + t_.OpenInt.P(k)];            
          end
        end            
        % t_.CleanIV = array2table([t_.CleanIV t_.C_iv_implied],'VariableNames',{'Strike','IV','IV_diff','Open_Int','IV_implied'});
        t_.CleanIV = array2table([t_.CleanIV],'VariableNames',{'Strike','IV','IV_diff','Open_Int'});
        t_.CleanIV.Open_Int(isnan(t_.CleanIV.IV)) = NaN;

        % Store cleaned option IV information
        OutTbl.Data{t}.Options_clean(i) = {t_.CleanIV};
                
    end
end

figure
% Fit the distributions
for t = 1:param.nDates

    nFutures = size(OutTbl.Data{t},1);
    OutTbl.Data{t}.pdf_RND = cell(nFutures,1);    
    % OutTbl.Data{t}.pdf_RND_fit = cell(nFutures,1);    

    for i = 1:nFutures
        
        try
            % Extract and unpack values
            t_.OptDat = OutTbl.Data{t,1}.Options_clean{i,1};
            t_.ObsIdx = ~isnan(t_.OptDat.Open_Int);                        
            t_.K =  t_.OptDat.Strike(t_.ObsIdx);            
            t_.tau = OutTbl.Data{t,1}.ttm(i);
            t_.iv = t_.OptDat.IV(t_.ObsIdx);
            t_.strikes = t_.OptDat.Strike(t_.ObsIdx);
            t_.fwd = OutTbl.Data{t,1}.Fwd_PX(i);
            t_.r_f =  OutTbl.Data{t,1}.r_f(i);
            t_.nOptions = size(t_.iv,1);

            % Calibrate SABR model parameters for the interpolation of the IV curve
            [t_.a,t_.b,t_.c,t_.d] = Cal_param_SABR(1,t_.tau,t_.fwd,t_.iv,OutTbl.Date(t),OutTbl.Data{t,1}.OptionExpiration(i),t_.K);
            

            % Figlewski grid
            t_.xaxmin = t_.fwd*exp(-0.5*t_.tau^0.5);% Minimum value from interval
            t_.xaxmax = t_.fwd*exp(0.5*t_.tau^0.5); % Maximum value from interval
            t_.xax = (t_.xaxmin:param.incr:t_.xaxmax)';
            t_.Est_pdf = nan(length(t_.xax),1);
            t_.pdf_rnd = nan(length(t_.xax),1);

            % Now we compute the volatilities from the estimated values           
            t_.s = blackvolbysabr(t_.a,t_.b,t_.c,t_.d,OutTbl.Date(t),OutTbl.Data{t,1}.OptionExpiration(i),t_.fwd,t_.xax);


            % Malz approach            
            t_.fwd = repmat(t_.fwd,size(t_.xax,1),1);
            t_.r_f = repmat(t_.r_f,size(t_.xax,1),1);
            t_.tau = repmat(t_.tau,size(t_.xax,1),1);

            t_.call_P = blackcall(t_.fwd, t_.xax, t_.s, t_.tau, t_.r_f);

            t_.tau = OutTbl.Data{t,1}.ttm(i);
            t_.r_f =  OutTbl.Data{t,1}.r_f(i);

            t_.fK = exp(t_.r_f*t_.tau)*diff(diff(t_.call_P))/param.incr;
            
            % Ensure no negative probabilities
            for cll=1:length(t_.fK)
                if t_.fK(cll)<0
                    t_.fK(cll)=0; % If any numerical result is negative, we convert it to zero
                end
            end
            t_.Est_pdf= t_.fK/sum(t_.fK);% Re-scale probabilities
            t_.minProb = min(find(t_.Est_pdf>0));
            t_.maxProb = max(find(t_.Est_pdf>0));
            t_.Est_pdf = t_.Est_pdf(t_.minProb:t_.maxProb,:);
            t_.xax = t_.xax(t_.minProb:t_.maxProb,:);
            

            % Finally, a kernel density estimation procedure is used to obtain a nonparametric representation of the probability density function.
            % Creating the kernel object
            t_.min_pdf_rnd=min(nonzeros(t_.Est_pdf));

            % Store the output
            t_.pdf_RND = [100-t_.xax t_.Est_pdf];

            % Center the distribution so that the mode corresponds to the forward
            t_.fwd = 100 - OutTbl.Data{t,1}.Fwd_PX(i);
            [~,t_.fwd_idx] = min(abs(t_.pdf_RND(:,1)-t_.fwd));
            [~,t_.mode_idx] = max(t_.pdf_RND(:,2));


            % Calibrate the skewed-T distribution
            x = t_.pdf_RND(:,1);
            y = t_.pdf_RND(:,2);
            t_.opts = optimoptions('lsqnonlin');
            t_.opts.MaxFunctionEvaluations = 3e5;
            opts = optimoptions('lsqnonlin');
            opts.FunctionTolerance = 1e-10;

            t_.SkewedT_Params = lsqnonlin(@(param) prob.AdrianSkewedT.pdffunc(x, param(1), param(2), param(3), param(4))-y*200, [0, 1, 1, 1], [-inf, eps, -inf, 1], [inf, inf, inf, inf], opts);
            
            % Compare 
            plot(x, prob.AdrianSkewedT.pdffunc(x, t_.SkewedT_Params(1), t_.SkewedT_Params(2), t_.SkewedT_Params(3), t_.SkewedT_Params(4))./200, 'b-', 'LineWidth', 2); 
            hold on
            plot(x, y, 'k:', 'LineWidth', 2); 
            xlim([-0.25 10])
            legend('fitted','observed')
            title(['Options maturing on ' datestr(OutTbl_raw.Data{t}.OptionExpiration(i)) ' as observed on ' datestr(OutTbl_raw.Date(t))])
            hold off
            drawnow
            

            % Store the IRNDs
            OutTbl.Data{t}.pdf_RND(i) = {t_.pdf_RND};

            % Store the skewed T Parameters
            OutTbl.Data{t}.SkewedTParams(i) = {t_.SkewedT_Params};

            clear t_
            

        catch err
           A = 1 ;
        end

    end
end

        
%% Create the option density plot for selected maturities
set(0, 'DefaultAxesFontName', 'Arial Narrow');
set(0, 'defaultTextFontName',  'Arial Narrow');
set(0, 'defaultAxesFontSize',  14);
figure
hold on
title('Fed Fund probability density by Dec 2024')
% Find run indices for first observation
t = find(param.Datevec == datetime('30/04/2024','InputFormat','dd/MM/yyyy'));% Time index, change here to desired observation time
i = find(OutTbl.Data{t,1}.OptionExpiration == datetime('13/12/2024','InputFormat','dd/MM/yyyy'));% Tenor index, change here to desired tenor
% Plot IRNDs
t_.x = OutTbl.Data{t,1}.pdf_RND{i}(:,1);
t_.y = OutTbl.Data{t,1}.pdf_RND{i}(:,2);
plot(t_.x, prob.AdrianSkewedT.pdffunc(t_.x,OutTbl.Data{t,1}.SkewedTParams{i}(1),OutTbl.Data{t,1}.SkewedTParams{i}(2),OutTbl.Data{t,1}.SkewedTParams{i}(3), OutTbl.Data{t,1}.SkewedTParams{i}(4)),...
    'Color',[0 .5 .5],'LineWidth',1.5)% Density plot

t = find(param.Datevec == datetime('06/05/2024','InputFormat','dd/MM/yyyy'));% Time index, change here to desired observation time
i = find(OutTbl.Data{t,1}.OptionExpiration == datetime('13/12/2024','InputFormat','dd/MM/yyyy'));% Tenor index, change here to desired tenor

% Plot IRNDs
t_.x = OutTbl.Data{t,1}.pdf_RND{i}(:,1);
t_.y = OutTbl.Data{t,1}.pdf_RND{i}(:,2);
plot(t_.x, prob.AdrianSkewedT.pdffunc(t_.x,OutTbl.Data{t,1}.SkewedTParams{i}(1),OutTbl.Data{t,1}.SkewedTParams{i}(2),OutTbl.Data{t,1}.SkewedTParams{i}(3), OutTbl.Data{t,1}.SkewedTParams{i}(4)),...
    'Color',[0 .25 .25],'LineWidth',1.5)% Density plot
xline(5.33,'LineStyle','-')% Manually set this to current Fed Funds rate
xline(4.6,'LineStyle',':')% Manually set this to Fed dot plot


xlim([0 8])
set(gcf,'color','w')
box off
legend({'Apr 30','May 6','Fed Funds','2024 Dot'},'Location','northwest')
legend box off
xlabel('SOFR in %')
ylabel('Probability in %')
