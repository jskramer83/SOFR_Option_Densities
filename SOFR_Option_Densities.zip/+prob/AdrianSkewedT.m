classdef AdrianSkewedT < prob.ToolboxFittableParametricDistribution
    % This is a sample implementation of the Skewed t-student distribution. You
    % can use this template as a model to implement your own distribution.
    % Create a directory called '+prob' somewhere on your path, and save this
    % file in that directory using a name that matches your distribution name.
    %
    %    An object of the AdrianSkewedT class represents a Skewed
    %    probability distribution with a specific location parameter NU and
    %    scale parameter OMEGA. This distribution object can be created directly
    %    using the MAKEDIST function or fit to data using the FITDIST function.
    %
    %    AdrianSkewedT methods:
    %       cdf                   - Cumulative distribution function
    %       fit                   - Fit distribution to data
    %       icdf                  - Inverse cumulative distribution function
    %       iqr                   - Interquartile range
    %       mean                  - Mean
    %       median                - Median
    %       paramci               - Confidence intervals for parameters
    %       pdf                   - Probability density function
    %       proflik               - Profile likelihood function
    %       random                - Random number generation
    %       std                   - Standard deviation
    %       truncate              - Truncation distribution to an interval
    %       var                   - Variance
    %
    %    AdrianSkewedT properties:
    %       DistributionName      - Name of the distribution
    %       nu                    - Value of the nu parameter
    %       omega                 - Value of the omega parameter
    %       NumParameters         - Number of parameters
    %       ParameterNames        - Names of parameters
    %       ParameterDescription  - Descriptions of parameters
    %       ParameterValues       - Vector of values of parameters
    %       Truncation            - Four-element vector indicating truncation limits
    %       IsTruncated           - Boolean flag indicating if distribution is truncated
    %       ParameterCovariance   - Covariance matrix of estimated parameters
    %       ParameterIsFixed      - Four-element boolean vector indicating fixed parameters
    %       InputData             - Structure containing data used to fit the distribution
    %       NegativeLogLikelihood - Value of negative log likelihood function
    %
    %    See also fitdist, makedist.

    %   Copyright 2020 The MathWorks, Inc.

    % All ProbabilityDistribution objects must specify a DistributionName
    properties(Constant)
        %DistributionName Name of distribution
        %    DistributionName is the name of this distribution.
        DistributionName = 'adrianskewedt';
    end

    % Optionally add your own properties here. For this distribution it's convenient
    % to be able to refer to the nu and omega parameters by name, and have them
    % connected to the proper element of the ParameterValues property. These are
    % dependent properties because they depend on ParameterValues.
    properties(Dependent=true)
        %XI Location
        xi

        %omega Scale parameter
        %    omega is the scale parameter for this distribution.
        omega

        %lambda Shape parameter
        %    lambda is the Shape parameter for this distribution.
        alpha

        %NU Degress of Freedom
        %    NU are the degrees of freedom
        nu
    end

    % All ParametricDistribution objects must specify values for the following
    % constant properties (they are the same for all instances of this class).
    properties(Constant)
        %NumParameters Number of parameters
        %    NumParameters is the number of parameters in this distribution.

        NumParameters = 4;

        %ParameterName Name of parameter
        %    ParameterName is a two-element cell array containing names
        %    of the parameters of this distribution.
        ParameterNames = {'xi', 'omega', 'alpha', 'nu'};

        %ParameterDescription Description of parameter
        %    ParameterDescription is a two-element cell array containing
        %    descriptions of the parameters of this distribution.
        ParameterDescription = {'location', 'scale', 'shape', 'freedom'};
    end

    % All ParametricDistribution objects must include a ParameterValues property
    % whose value is a vector of the parameter values, in the same order as
    % given in the ParameterNames property above.
    properties(GetAccess='public',SetAccess='protected')
        %ParameterValues Values of the distribution parameters
        %    ParameterValues is a two-element vector containing the nu and lambda
        %    values of this distribution.
        ParameterValues
    end

    methods
        % The constructor for this class can be called with a set of parameter
        % values or it can supply default values. These values should be
        % checked to make sure they are valid. They should be stored in the
        % ParameterValues property.
        function pd = AdrianSkewedT(xi, omega, alpha, nu)
            arguments
                xi (1,1) double = 0
                omega (1,1) double {mustBePositive} = 1
                alpha (1,1) double = 0
                nu (1,1) double  {mustBeReal, mustBeGreaterThanOrEqual(nu, 1)} = Inf
            end

            pd.ParameterValues = [xi omega, alpha, nu];

            % All FittableParametricDistribution objects must assign values
            % to the following two properties. When an object is created by
            % the constructor, all parameters are fixed and the covariance
            % matrix is entirely zero.
            pd.ParameterIsFixed = [true true true true];
            pd.ParameterCovariance = zeros(pd.NumParameters);
        end

        % Implement methods to compute the mean, variance, and standard
        % deviation.
        function m = mean(this)
            delta = (this.alpha)./sqrt(1+this.alpha.^2);
            mu = delta*sqrt(this.nu/pi)*gamma(0.5*(this.nu-1))./gamma(0.5*this.nu);
            m = this.xi + this.omega*mu;
        end
        function s = std(this)
            s = sqrt(this.var);
        end
        function v = var(this)
            delta = (this.alpha)./sqrt(1+this.alpha.^2);
            mu = delta*sqrt(this.nu/pi)*gamma(0.5*(this.nu-1))./gamma(0.5*this.nu);
            v = this.omega*(this.nu/(this.nu-2)-mu.^2);
        end
    end
    methods
        % If this class defines dependent properties to represent parameter
        % values, their get and set methods must be defined. The set method
        % should mark the distribution as no longer fitted, because any
        % old results such as the covariance matrix are not valid when the
        % parameters are changed from their estimated values.
        function this = set.xi(this,xi)
            arguments
                this
                xi
            end
            this.ParameterValues(1) = xi;
            this = invalidateFit(this);
        end
        function this = set.omega(this,omega)
            arguments
                this
                omega (1,1) double
            end
            this.ParameterValues(2) = omega;
            this = invalidateFit(this);
        end
        function this = set.alpha(this,alpha)
            arguments
                this
                alpha
            end
            this.ParameterValues(3) = alpha;
            this = invalidateFit(this);
        end
        function this = set.nu(this,nu)
            arguments
                this
                nu (1,1) double = Inf
            end
            this.ParameterValues(4) = nu;
            this = invalidateFit(this);
        end

        function xi = get.xi(this)
            xi = this.ParameterValues(1);
        end
        function omega = get.omega(this)
            omega = this.ParameterValues(2);
        end
        function alpha = get.alpha(this)
            alpha = this.ParameterValues(3);
        end
        function nu = get.nu(this)
            nu = this.ParameterValues(4);
        end
    end
    methods(Static)
        % All FittableDistribution classes must implement a fit method to fit
        % the distribution from data. This method is called by the FITDIST
        % function, and is not intended to be called directly
        function pd = fit(x,varargin)
            %FIT Fit from data
            %   P = prob.AdrianSkewedT.fit(x)
            %   P = prob.AdrianSkewedT.fit(x, NAME1,VAL1, NAME2,VAL2, ...)
            %   with the following optional parameter name/value pairs:
            %
            %          'censoring'    Boolean vector indicating censored x values
            %          'frequency'    Vector indicating frequencies of corresponding
            %                         x values
            %          'options'      Options structure for fitting, as create by
            %                         the STATSET function

            % Get the optional arguments. The fourth output would be the
            % options structure, but this function doesn't use that.
            [x,cens,freq] = prob.ToolboxFittableParametricDistribution.processFitArgs(x,varargin{:});

            % This distribution was not written to support censoring or to process
            % a frequency vector. The following utility expands x by the frequency
            % vector, and displays an error message if there is censoring.
            x = prob.ToolboxFittableParametricDistribution.removeCensoring(x,cens,freq,'laplace');
            freq = ones(size(x));

            % % % Calculate moments
            M1 = mean(x);
            M2 = mean(x.^2);
            M3 = mean(x.^3);
            M4 = mean(x.^4);

            % Create optimization variables
            mu = optimvar("mu");
            nu = optimvar("nu","LowerBound",1+eps);
            delta = optimvar("delta", "LowerBound",-1+eps, "UpperBound",1-eps);
            omega = optimvar("omega","LowerBound",eps);
            xi = optimvar("xi");

            % Set initial starting point for the solver
            initialPoint.mu = zeros(size(mu));
            initialPoint.nu = zeros(size(nu));
            initialPoint.delta = zeros(size(delta));
            initialPoint.omega = zeros(size(omega));
            initialPoint.xi = zeros(size(xi));

            % Create problem
            problem = eqnproblem;

            % Define problem equations
            problem.Equations.equation1 = xi + omega*mu == M1;
            problem.Equations.equation2 = (nu*omega^2)/(nu - 2) + 2*mu*omega*xi + xi^2 == M2;
            problem.Equations.equation3 = - (mu*nu*(delta^2 - 3)*omega^3)/(nu - 3) + (3*nu*omega^2*xi)/(nu - 2) + 3*mu*omega*xi^2 + xi^3 == M3;
            problem.Equations.equation4 = xi^4 + 4*mu*omega*xi^3 + (3*nu^2*omega^4)/((nu - 3)*(nu - 4)) + (6*nu*omega^2*xi^2)/(nu - 2) - (4*mu*nu*omega^3*xi*(delta^2 - 3))/(nu - 3) == M4;
            f1 = fcn2optimexpr(@gamma, 0.5*nu, OutputSize=[1,1]);
            f2 = fcn2optimexpr(@gamma, 0.5*(nu-1), OutputSize=[1,1]);
            problem.Equations.equation5 = delta*(nu/pi)^0.5*f2/f1 == mu;

            solution = solve(problem,initialPoint, "Options", optimoptions('lsqnonlin', 'Display','none'));

            alpha = solution.delta/sqrt(1-solution.delta^2);

            % Perform the MLE to estimate the distribution parameters.
            f = @(data, xi, omega, alpha, nu) ...
                prob.AdrianSkewedT.pdffunc(...
                data, xi, omega, alpha, nu);
            lb = [-Inf; eps; -Inf; 1];
            ub = [Inf; Inf; Inf; Inf];
            params0 = [solution.xi; solution.omega; alpha; solution.nu];

            options = statset;
            options.MaxIter = 1e5;
            options.MaxFunEvals = 1e5;
            params = mle(x, 'pdf', f, ...
                'start', params0, ...
                'LowerBound', lb, ...
                'UpperBound', ub, Options=options);

            % Create the distribution by calling the constructor.
            pd = prob.AdrianSkewedT(params(1),params(2), params(3), params(4));

            % Fill in remaining properties defined above
            pd.ParameterIsFixed = [false false false false];
            [nll,acov] = prob.AdrianSkewedT.likefunc([params(1) params(2) params(3) params(4)],x);
            pd.ParameterCovariance = acov;

            % Assign properties required for the FittableDistribution class
            pd.NegativeLogLikelihood = nll;
            pd.InputData = struct('data',x,'cens',[],'freq',freq);
        end

        % The following static methods are required for the
        % ToolboxParametricDistribution class and are used by various
        % Statistics and Machine Learning Toolbox functions. These functions operate on
        % parameter values supplied as input arguments, not on the
        % parameter values stored in a AdrianSkewedT object. For
        % example, the cdf method implemented in a parent class invokes the
        % cdffunc static method and provides it with the parameter values.
        function [nll,acov] = likefunc(params,x) % likelihood function
            xi = params(1);
            omega = params(2);
            alpha = params(3);
            nu = params(4);

            nll = -sum(prob.AdrianSkewedT.logpdffunc(x, xi, omega, alpha, nu));

            % Asymptotic parameter variance-covariance matrix. In the
            % absence of a closed-form expression for this, we can estimate
            % it using MLECOV.
            acov = mlecov(params,x,'logpdf',@prob.AdrianSkewedT.logpdffunc);
        end

        function y = cdffunc(x, xi, omega, alpha, nu)          % cumulative distribution function

            arguments
                x (1,:) double
                xi (1,1) double = 0
                omega (1,1) double {mustBePositive} = 1
                alpha (1,1) double = 0
                nu (1,1) double  {mustBeReal, mustBeGreaterThanOrEqual(nu, 1)} = Inf
            end

            z = (x-xi)./omega;
            if isinf(nu)
                y = psn(x,xi,omega,alpha); 
            else

                if isinteger(nu)
                    %Get the correlation matrix from the covariance matrix Omega
                    delta=alpha/sqrt(1+alpha^2);
                    %equivalent of rbind
                    q=[1; -delta];
                    %equivalent of cbind
                    w=[-delta; 1];
                    %equivalent of rbind(...)
                    Obig=[q, w];

                    if nu==Inf
                        mu=zeros(1,2);
                        y=2*mvncdf([0 x],mu,Obig);
                    else
                        y=2*mvtcdf([0 x],Obig,nu);
                    end
                else
                    if isinf(z)
                        y=(1+sign(z))/2;
                    else
                        y=integral(@(x) prob.AdrianSkewedT.pdffunc(x, xi, omega, alpha, nu),-Inf,z);
                    end
                end

            end


        end

        function y = pdffunc(x, xi, omega, alpha, nu)         % probability density function

            arguments
                x double
                xi (1,1) double = 0
                omega (1,1) double {mustBePositive} = 1
                alpha (1,1) double = 0
                nu (1,1) double {mustBeGreaterThanOrEqual(nu, 1)} = Inf
            end

            %Define the standardized random variable
            z=(x-xi)./omega;
            if nu==Inf
                y=2.*normpdf(z).*normcdf( alpha.*z)./omega;
            else
                y=2.*tpdf(z,nu).*tcdf(alpha.*z.*sqrt((1+nu)./(z.^2+nu)),nu+1)./omega;
            end
            y = max(y, eps);

        end

        function y = logpdffunc(x, xi, omega, alpha, nu)         % probability density function

            arguments
                x double
                xi (1,1) double = 0
                omega (1,1) double {mustBePositive} = 1
                alpha (1,1) double = 0
                nu (1,1) double  {mustBeReal, mustBeGreaterThanOrEqual(nu, 1)} = Inf
            end

            z=(x-xi)./omega;
            if nu==Inf
                y = log(2) + log(1/sqrt(2*pi)) - z.^2/2 + log(normcdf( alpha.*z)) + log(1./omega);
            else
                y = log(2) + log(tpdf(z,nu)) + log(tcdf(alpha.*z.*sqrt((1+nu)./(z.^2+nu)),nu+1)) + log(1./omega);
            end

        end

        function y = invfunc(u, xi, omega, alpha, nu, tol)         % inverse cdf

            arguments
                u double
                xi (1,1) double = 0
                omega (1,1) double {mustBePositive} = 1
                alpha (1,1) double = 0
                nu (1,1) double  {mustBeReal, mustBeGreaterThanOrEqual(nu, 1)} = Inf
                tol (1,1) double {mustBeGreaterThan(tol, 0)} = 1e-8
            end

            if nu == Inf
                y = qsn(u, xi, omega, alpha);
            else

                %begin program computations
                max_q =  sqrt(finv(u,1,nu));
                min_q = -sqrt(finv(1-u,1,nu));

                if alpha==Inf
                    y=xi+omega*max_q;
                elseif alpha==-Inf
                    y=xi+omega*min_q;
                else
                    %Set the values of the vector of probabilities such that it admits nan's
                    a=isnan(u);
                    ind_nan=find(a==1);
                    ind_p1=find(u==1);
                    ind_p0=find(u==0);

                    ind_p_L_0=find(u<0);
                    ind_p_H_1=find(u>1);

                    u(ind_nan)=0.5;
                    u(ind_p1)=0.5;
                    u(ind_p0)=0.5;
                    u(ind_p_L_0)=0.5;
                    u(ind_p_H_1)=0.5;

                    cum=skt_cumulants(0,1,alpha,max(nu,5),4);
                    g1=cum(3)/cum(2)^(3/2);
                    g2=cum(4)/cum(2)^2;
                    x=norminv(u);
                    x=(x+(x.^2-1).*g1./6+x.*(x.^2-3).*g2./24-x.*(2.*x.^2-5).*g1.^2./36);
                    x=cum(1)+sqrt(cum(2))*x;
                    max_err=1;
                    while (max_err>tol)
                        x1=x-(prob.AdrianSkewedT.cdffunc(x,0,1,alpha,nu)-u)./prob.AdrianSkewedT.pdffunc(x,0,1,alpha,nu);
                        x1=min(x1,max_q);
                        x1=max(x1,min_q);
                        max_err=max(abs(x1-x)./(1+abs(x)));
                        x=x1;
                    end

                    x(ind_nan)=nan;
                    x(ind_p_L_0)=nan;
                    x(ind_p_H_1)=nan;
                    x(ind_p1)=Inf;
                    x(ind_p0)=-Inf;

                    y=xi+omega*x;
                end

            end

        end

        function y = randfunc( xi, omega, alpha, nu, T) % random number generator

            arguments
                xi (1,1) double = 0
                omega (1,1) double {mustBePositive} = 1
                alpha (1,1) double = 0
                nu (1,1) double  {mustBeReal, mustBeGreaterThanOrEqual(nu, 1)} = Inf
                T (1,1) double {mustBeInteger} = 1
            end

            z=rsn(T,0,omega,alpha);
            if nu==Inf
                %Creates a (1*n) matrix with random numbers from a skew normal distribution
                %where the location parameter is set equal to zero
                y=z+xi;
            else
                %Creates a (1*n) matrix with random numbers from a skew normal distribution
                %where the location parameter is set equal to zero

                v=chi2rnd(nu,1,T)./nu;
                y=z./sqrt(v)+xi;
            end

        end

    end

    methods(Static,Hidden)
        % All ToolboxDistributions must implement a getInfo static method
        % so that Statistics and Machine Learning Toolbox functions can get information about
        % the distribution.
        function info = getInfo

            % First get default info from parent class
            info = getInfo@prob.ToolboxFittableParametricDistribution('prob.AdrianSkewedT');

            % Then override fields as necessary
            info.name = 'AdrianSkewedT';
            info.code = 'AdrianSkewedT';
            % info.pnames is obtained from the ParameterNames property
            % info.pdescription is obtained from the ParameterDescription property
            % info.prequired = [false false] % Change if any parameter must
            % be specified before fitting.
            % An example would be the N
            % parameter of the binomial
            % distribution.
            % info.hasconfbounds = false     % Set to true if the cdf and
            % icdf methods can return
            % lower and upper bounds as
            % their 2nd and 3rd outputs.
            % censoring = false              % Set to true if the fit
            % method supports censoring.
            % info.support = [-Inf, Inf]     % Set to other lower and upper
            % bounds if the distribution
            % doesn't cover the whole real
            % line. For example, for afi
            % distribution on positive
            % values use [0, Inf].
            % info.closedbound = [false false] % Set the Jth value to
            % true if the distribution
            % allows x to be equal to the
            % Jth element of the support
            % vector.
            % info.iscontinuous = true       % Set to false if x can take
            % only integer values.
            info.islocscale = true;          % Set to true if this is a
            % location/scale distribution
            % (no other parameters).
            % info.uselogpp = false          % Set to true if a probability
            % plot should be drawn on the
            % log scale.
            % info.optimopts = false         % Set to true if the fit
            % method can be called with an
            % options structure.
            info.logci = [false true];       % Set to true for a parameter
            % that should have its Wald
            % confidence interval computed
            % using a normal approximation
            % on the log scale.
        end
    end
end % classdef

function r = rsn(n,xi,omega,alpha)

arguments
    n (1,1) double {mustBeInteger} = 1
    xi (1,1) double = 0
    omega (1,1) double = 1
    alpha (1,1) double = 0
end

u1=normrnd(0,1,1,n);
u2=normrnd(0,1,1,n);
id=(u2>alpha*u1);
u1(id)=-u1(id);
r=xi+omega.*u1;

end

function q=qsn(p,xi,omega,alpha,tol)

arguments
    p double {mustBeInRange(p, 0, 1)}
    xi (1,1) double = 0
    omega (1,1) double = 1
    alpha (1,1) double = 0
    tol (1,1) double = 1e-8
end

na= (p<0)|(p>1)|(isnan(p));
zero= (p==0);
one= (p==1);
p(zero|one|na)=0.5;
cum=sn_cumulants(alpha,4);
g1=cum(3)./cum(2).^(3/2);
g2=cum(4)./cum(2).^2;
x=norminv(p);
x=x+(x.^2+1).*g1./6+x.*(x.^2-3 ).*g2./ ...
    24-x.*(2.*x.^2-5).*g1.^2./36;
x=cum(1)+sqrt(cum(2)).*x; %a Cornish-Fisher start
max_err=1;
while (max_err>tol)
    x1=x-(psn(x,0,1,alpha)-p)./dsn(x,0,1,alpha);
    max_err=max(abs(x1-x)./(1.*abs(x)));
    x=x1;
end
x(na)=NaN;
x(zero)=-Inf;
x(one)=Inf;
q=xi+omega.*x;
end

function cum=sn_cumulants(omega,n)

arguments
    omega = 0
    n = 4
end

delta=omega./sqrt(1+omega.^2);
kv=cumulants_half_norm(n);
if length(kv)>n
    kv=kv(1:(end-1));
end
kv(2)=kv(2)-1;
[app2,app1]=meshgrid(1:n,delta);
kappa=app1.^app2.*repmat(kv,length(omega),1);
kappa(:,2)=kappa(:,2)+1;
cum=kappa;

end

function cum2=cumulants_half_norm(n)

arguments
    n = 4
end
n=max(n,2);
n=fix(2*ceil(n/2));
half_n=fix(n/2);
m=0:(half_n-1);
a=sqrt(2/pi)./(gamma(m+1).*(2.^m).*(2.*m+1));
signs=ones(1,half_n);
signs(2:2:end)=-1;
%a=reshape([signs.*a; zeros(1,half_n)],1,2*length(a));
a=[signs.*a; zeros(1,half_n)]; %per MATLAB una matrice e' anche
%un vettore, letta per colonna
coeff=repmat(a(1),1,n);
for k=2:n
    ind=1:(k-1);
    coeff(k)=a(k)-sum(ind.*coeff(ind).*a(fliplr(ind)))./k;
end
kappa=coeff.*gamma((1:n)+1);
kappa(2)=1+kappa(2);
cum2=kappa;

end

function cum=skt_cumulants(xi, omega, alpha, nu, n)
%SKT_CUMULANTS cumulants of the skew-t distribution.
%SKT_CUMULANTS(xi, omega, alpha, nu, n) computes the cumulants up to order n of the skew-t distribution with
%the selected parameters. The returned object is a vector of lemgth n if the parameters
%are all scalar, otherwise a matrix with n coilumns.
%
%DESCRIPTION
%
%Expressions of the moments and other details on the skew-t distribution are given in
%reference bellow. These formulae are used by skt_cumulants to compute the cumulants.
%
%skt_cumulants_inversion searches the set of shape and df parameters of the skew-t family,
%attempting to match the third and fourth cumulants with those of the supplied vector cum.
%This search is done numerically twice, once using optim and a second time using nlminb, to
%the accuracy abstol; the best matching solution is retained. If the required accuracy of the
%matching is not achieved by any of the two methods, a warning message is issued. After this
%step, the other two parameters (location and scale) are computed via simple algebra.
%
%The moment generating function (hence the cumulant generating function)
%of the distribution is given in the refence below.
%
%USAGE
%
%ARGUMENTS
%
%xi         a vector of location parameters (default is 0).
%omega     a vector of scale parameters (default is 1).
%alpha      a vector of shape parameter (default is 0).
%nu         degrees of freedom (scalar); (default is df=Inf which corresponds to the skew-normal distribution).
%n	        a scalar integer of the maximal order or cumulants required; it must be from 1 to 4 and smaller than df (default is 4).
%
%REFERENCES
%
%Azzalini, A. (1985). A class of distributions which includes the normal
%ones. Scand. J. Statist. 12, 171-178.
%
%NOTE
%
%The joint use skt_cumulants_inversion and sample_centralmoments allows to fit a skew-t
%distribution by the method of moments; see example bellow. Note however, that for
%stability reasons, this is not adopted as the standard method for producing initial values
%of the MLE search.

%SEE ALSO
%
%sn_cumulants, dskt, sample_centralmoments, optim, nlminb
%
%EXAMPLES
%
%a   = skt_cumulants(10, 2, -8, 5.2)    #Result is: 8.1310    3.0070  -12.2242  144.2662
%b   = skt_cumulants( 0, 1,  0, 5)      #Result is:     0    1.6667         0   16.6667
%c   = skt_cumulants( 0, 1,  3, 5)      #Result is: 0.9003    0.8561    1.6846   11.9140
%d   = skt_cumulants( 0, 1,  9, 5)      #Result is: 0.9432    0.7770    1.7070   11.8093
%e   = skt_cumulants(

arguments
    xi (1,1) double = 0
    omega (1,1) double {mustBePositive} = 1
    alpha (1,1) double = 0
    nu (1,1) double = Inf
    n (1,1) double {mustBeInRange(n, 1, 4), mustBeLessThan(n, nu)} = 4
end

if nu==Inf
    cum=sn_cumulants(alpha,n);
else
    par=[xi omega alpha];
    delta=par(:,3)./sqrt(1+par(:,3).^2);
    mu=delta.*sqrt(nu./pi).*exp(gammaln((nu-1)./2)-gammaln(nu./2));
    a=size(par);
    b=a(1,1);
    cum=zeros(b,n);
    cum(:,:)=NaN;
    cum(:,1)=mu;
    if n>1
        cum(:,2)=nu./(nu-2)-mu.^2;
    end
    if n>2
        cum(:,3)=mu.*(nu.*(3-delta.^2)/(nu-3)-3.*nu./(nu-2)+2.*mu.^2);
    end
    if n>3
        cum(:,4)=(3.*nu.^2/((nu-2)*(nu-4))-4.*mu.^2*nu*(3-delta.^2)/(nu-3)+6.*mu.^2.*nu./(nu-2)-3*mu.^4)-3*cum(:,2).^2;
    end
    [app2,app1]=meshgrid(1:n,omega);
    kap=app1.^app2;

    cum=cum.*kap;
    cum(:,1)=cum(:,1)+par(:,1);
end
end

function to=T_Owen(h,a,jmax,cut_point)
%T_Owen
%Owen's function
%
%DESCRIPTION
%
%Evaluates funtion T(h,a) studied by D.B.Owen
%
%USAGE
%
%T_Owen(h, a, jmax, cut_point)
%
%REQUIRED ARGUMENTS
%
%h	a numerical vector. Missing values (NaN) and Inf are allowed.
%
%a	a numerical scalar. Inf is allowed.
%
%OPTIONAL ARGUMENTS
%
%jmax	an integer scalar value which regulates the accuracy of the
% 	result (default is 50). See DETAILS below for explanation.
%
%cut_point	a scalar value which regulates the behaviour of the
% 		algorithm (default is 6). See DETAILS below for explanation.
%
%VALUE
%
%a numerical vector
%
%DETAILS
%
%If a>1 and 0<h<=cut_point, a series expansion is used, truncated after
%jmax terms. If a>1 and h>cut_point, an asymptotic approximation is used.
%In the other cases, various reflection properties of the function are
%exploited. See the reference below for more information.
%
%BACKROUND
%
%The function T(h,a) is useful for the computation of the bivariate
%normal distribution function and related quantities. See the reference
%below for more information.
%
%REFERENCES
%
%Owen, D. B. (1956). Tables for computing bivariate normal probabilities.
%Ann. Math. Statist. 27, 1075-1090.
%
%SEE ALSO
%
%pnorm2, psn
%
%EXAMPLES
%
%owen = T_Owen(1:10, 2)

arguments
    h
    a (1,1) double
    jmax (1,1) double {mustBeNonNan} = 50
    cut_point (1,1) double {mustBeNonNan} = 6
end

aa=abs(a);
ah=abs(h);
if (aa==Inf)
    to=0.5.*normcdf(-ah);
    return;
end
if (aa==0)
    to=zeros(1,length(h));
    return;
end
na=isnan(h);
inf= (ah==Inf);
ah(na|inf)=0;
if (aa<=1)
    owen=T_int(ah,aa,jmax,cut_point);
else
    owen=0.5.*normcdf(ah)+normcdf(aa.*ah).*(0.5-normcdf(ah))- ...
        T_int(aa.*ah,(1/aa),jmax,cut_point);
end
owen(na)=NaN;
owen(inf)=0;
to=owen*sign(a);
end

function ti=T_int(h,a,jmax,cut_point)
i=0:jmax;
low=(h<=cut_point);
hL=h(low);
hH=h(~low);
L=length(hL);
seriesL=zeros(1,L);
seriesH=zeros(1,length(h)-L);
if (L>0)
    [Y,X]=meshgrid(i,hL);
    b=fui(X,Y);
    tcumb=cumsum(b,2);
    for j=1:size(tcumb,2)
        b1(:,j)=tcumb(:,j).*(exp(-0.5.*hL.^2))';
    end
    matr=ones(jmax+1,L)-(b1');
    jk=repmat([1 -1],1,jmax);
    jk=jk(1:(jmax+1))./(2.*i+1);
    for j=1:size(matr,2)
        matr(:,j)=matr(:,j).*jk';
    end
    matr=(matr')*(a.^(2.*i+1))';
    seriesL=(atan(a)-matr')./(2.*pi);
end
if ~isempty(hH)
    seriesH=atan(a).*exp(-0.5.*(hH.^2).*a./atan(a)).* ...
        (1+0.00868.*(hH.^4).*a.^4)./(2.*pi);
end
series=[seriesL seriesH];
app=1:length(h);
id=[app(low) app(~low)];
series(id)=series; %re-sets in original order
ti=series;
end


function ff=fui(h,i)
ff=(h.^(2.*i))./((2.^i).*gamma(i+1));
end

function p=psn(x,xi,omega,alpha)
%dsn psn qsn rsn
%Skew-Normal Distribution
% 
%DESCRIPTION
% 
%Density function, distribution function, quantiles and random number
%generation for the skew-normal (SN) distribution.
% 
%USAGE
% 
%dsn(x, location, scale, shape)
%psn(q, location, scale, shape)
%qsn(p, location, scale, shape, tol)
%rsn(n, location, scale, shape)
% 
%REQUIRED ARGUMENTS
% 
%x	vector of quantiles. Missing values (NaN) are allowed.
%q	vector of quantiles. Missing values (NaN) are allowed.
%p	vector of probabilities. Missing values (NaN) are allowed.
% 
%OPTIONAL ARGUMENTS
% 
%location vector of location parameters (default is 0).
%scale	  vector of (positive) scale parameters (default is 1).
%shape	  vector of shape parameters. With 'psn' and 'qsn', it must 
%	  be of length 1 (default is 0).
%n	  sample size (default is 1).
%tol	  a scal value which regulates the accuracy of the result.
%         (default is 1e-8) 
%
%VALUE
% 
%density (dsn), probability (psn), quantile (qsn) or  random sample (rsn)
%from the skew-normal distribution with given location, scale and shape
%parameters.
% 
%BACKGROUND
% 
%The family of skew-normal distributions is an extension of the normal
%family, via the introdution of a shape parameter which regulates
%skewness; when shape=0, the skew-normal distribution reduces to the
%normal one.  The density of the SN distribution when location=0 and
%scale=1 is 2*dnorm(x)*pnorm(shape*x). A multivariate version of the
%distribution exists. See the references below for additional
%information.
% 
%DETAILS
% 
%psn make use of function T_Owen
% 
%REFERENCES
% 
%Azzalini, A. (1985). A class of distributions which includes the normal
%ones. Scand. J. Statist. 12, 171-178.
% 
%Azzalini, A. and Dalla Valle, A. (1996). The multivariate skew-normal
%distribution. Biometrika 83, 715-726.
% 
%SEE ALSO
% 
%T_Owen, dmsn, sn_mle
% 
%EXAMPLES
% 
%pdf = dsn([-3:0.1:3],0,1,3)
%cdf = psn([-3:0.1:3],0,1,3)
%qu = qsn([0.1:0.1:0.9],0,1,-2)
%rn = rsn(100, 5, 2, 5)

arguments
    x
    xi {mustBeNonNan} = 0
    omega {mustBeNonNan} = 1
    alpha {mustBeNonNan} = 0
end

p=normcdf( (x-xi)./omega ) ...
   -2.* T_Owen( ((x-xi)./omega),alpha );

end

function d=dsn(x,xi,omega,alpha)
%dsn psn qsn rsn
%Skew-Normal Distribution
% 
%DESCRIPTION
% 
%Density function, distribution function, quantiles and random number
%generation for the skew-normal (SN) distribution.
% 
%USAGE
% 
%dsn(x, location, scale, shape)
%psn(q, location, scale, shape)
%qsn(p, location, scale, shape, tol)
%rsn(n, location, scale, shape)
% 
%REQUIRED ARGUMENTS
% 
%x	vector of quantiles. Missing values (NaN) are allowed.
%q	vector of quantiles. Missing values (NaN) are allowed.
%p	vector of probabilities. Missing values (NaN) are allowed.
% 
%OPTIONAL ARGUMENTS
% 
%location vector of location parameters (default is 0).
%scale	  vector of (positive) scale parameters (default is 1).
%shape	  vector of shape parameters. With 'psn' and 'qsn', it must 
%	  be of length 1 (default is 0).
%n	  sample size (default is 1).
%tol	  a scal value which regulates the accuracy of the result.
%         (default is 1e-8) 
%
%VALUE
% 
%density (dsn), probability (psn), quantile (qsn) or  random sample (rsn)
%from the skew-normal distribution with given location, scale and shape
%parameters.
% 
%BACKGROUND
% 
%The family of skew-normal distributions is an extension of the normal
%family, via the introdution of a shape parameter which regulates
%skewness; when shape=0, the skew-normal distribution reduces to the
%normal one.  The density of the SN distribution when location=0 and
%scale=1 is 2*dnorm(x)*pnorm(shape*x). A multivariate version of the
%distribution exists. See the references below for additional
%information.
% 
%DETAILS
% 
%psn make use of function T_Owen
% 
%REFERENCES
% 
%Azzalini, A. (1985). A class of distributions which includes the normal
%ones. Scand. J. Statist. 12, 171-178.
% 
%Azzalini, A. and Dalla Valle, A. (1996). The multivariate skew-normal
%distribution. Biometrika 83, 715-726.
% 
%SEE ALSO
% 
%T_Owen, dmsn, sn_mle
% 
%EXAMPLES
% 
%pdf = dsn([-3:0.1:3],0,1,3)
%cdf = psn([-3:0.1:3],0,1,3)
%qu = qsn([0.1:0.1:0.9],0,1,-2)
%rn = rsn(100, 5, 2, 5)
arguments
    x
    xi {mustBeNonNan} = 0
    omega {mustBeNonNan} = 1
    alpha {mustBeNonNan} = 0
end

d=2.*normpdf( (x-xi)./omega ) .* normcdf( (alpha.*(x-xi)./omega) )./omega;

end