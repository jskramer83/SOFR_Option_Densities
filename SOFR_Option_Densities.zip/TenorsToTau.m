function [tau] = TenorsToTau(Tenors)
% This function converts the text identifier of a tenor into a
% numeric time to maturity denoted in number of years
if size(Tenors,2) > 1
    Tenors = Tenors';
end

% First, extract the numeric part
A = regexp(Tenors,'\d*','Match');
idx_empty = cellfun(@(x) isempty(x),A,'UniformOutput',true);
if sum(idx_empty) > 0
    try
        A{idx_empty} = repmat({'1'},sum(idx_empty),1);
    catch err
        A(idx_empty) = {{'1'}};
    end
else
end

% Second, identify the time units belonging to the numeric part
B = A;
for i = 1:size(A,1)
    for j = 1:size(A{i,:},2)
        DigitLoc = cell2mat(strfind(Tenors(i),A{i}{j}));
        Len = length(A{i}{j});
        if ~isempty(DigitLoc)
            try
                B{i,1}(j) = cellfun(@(x) x(DigitLoc(j)+Len),Tenors(i),'UniformOutput',false);
            catch err
                B{i,1}(j) = cellfun(@(x) x(DigitLoc+Len),Tenors(i),'UniformOutput',false);
            end
        else
            B{i,1}(j) = Tenors(i);
        end
    end
end

% Convert the cell to a matrix
tmp = cell2mat(cellfun(@(x) size(x),A,'UniformOutput',false));
idx = tmp(:,2) == 1;
idx_ = find(idx);
for i = idx_'
    A{i} = cat(2,A(i),{num2str(0)});
    B{i} = cat(2,B(i),{''});
end
A = vertcat(A{:});
A(idx) = vertcat(A{idx});
A = cell2mat(cellfun(@(x) str2num(x),A,'UniformOutput',false));
B = vertcat(B{:});
B(idx) = vertcat(B{idx});

% Convert the time units into numbers
B_numeric = zeros(size(B,1),size(B,2));
Strings = {{'O/N','ON'};{'T/N','TN'};{'D'};{'W'};{'M'};{'Y'}};
Units = [(1/5)/4;(2/5)/4;(1/5)/4;1/4;1;12];
MapTable = [table(Strings) table(Units)];
for j = 1:size(B,2)
    idx = zeros(size(B,1),size(MapTable,1));
    for i = 1:size(MapTable,1)
        idx(:,i) = cell2mat(cellfun(@(x) contains(x,MapTable.Strings{i}),B(:,j),'UniformOutput',false)) & ~any(idx(:,1:i),2);
        B_numeric(logical(idx(:,i)),j) = MapTable.Units(i);
    end
end

% Multiply the timespans with the time units
C = zeros(1,size(A,1));
for i = 1:size(A,2)
    C = C + A(:,i)'.*B_numeric(:,i)';
end

% Express time to maturity in terms of years
tau = C./12;

% Re-transform tau so that it is a row vector
if size(tau,1) > 1
    tau = tau';
end


end