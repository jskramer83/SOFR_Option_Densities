function [Alpha2,Beta2,Rho2,Nu2 ] = Cal_param_SABR(beta,tau,fwd,mkt_volatility,Settle,ExerciseDate,MarketStrikes)
%%%% This function shows how to use an alternative calibration method where the value of ? (Beta) is again predetermined
%%%% Taking into consideration Hagan(2002) the value of Beta is equal to 1
%%%% in the case of foreign exchange options.


Beta2 = beta;% Define the predetermined Beta 
% Year fraction from Settle to option maturity
T = tau;
[~,idx] = min(abs(MarketStrikes-fwd));
ATMVolatility=mkt_volatility(idx);
% ATMVolatility=mkt_volatility(3);
CurrentForwardValue=fwd;
MarketVolatilities=mkt_volatility;

% This function solves the SABR at-the-money volatility equation as a
% polynomial of Alpha
alpharoots = @(Rho,Nu) roots([...
    (1 - Beta2)^2*T/24/CurrentForwardValue^(2 - 2*Beta2) ...
    Rho*Beta2*Nu*T/4/CurrentForwardValue^(1 - Beta2) ...
    (1 + (2 - 3*Rho^2)*Nu^2*T/24) ...
    -ATMVolatility*CurrentForwardValue^(1 - Beta2)]);

% This function converts at-the-money volatility into Alpha by picking the
% smallest positive real root 
atmVol2SabrAlpha = @(Rho,Nu) min(real(arrayfun(@(x) ...
    x*(x>0) + realmax*(x<0 || abs(imag(x))>1e-6), alpharoots(Rho,Nu))));
% Calibrate Rho and Nu (while converting at-the-money volatility into Alpha
% using atmVol2SabrAlpha)
objFun = @(X) MarketVolatilities - ...
   blackvolbysabr(atmVol2SabrAlpha(X(1), X(2)), ...
    Beta2, X(1), X(2), Settle, ExerciseDate, CurrentForwardValue, ...
    MarketStrikes);

X = lsqnonlin(objFun, [0 0.5], [-1 0], [1 Inf]);

Rho2 = X(1);
Nu2 = X(2);
% Obtain final Alpha from at-the-money volatility using calibrated parameters
Alpha2 = atmVol2SabrAlpha(Rho2, Nu2);

