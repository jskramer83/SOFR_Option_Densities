function [price delta] = blackput(F, K, vol, ttm, rf)

d1 = (log(F./K) + (vol.^2/2)*ttm) ./ (vol*sqrt(ttm));
d2 = d1 - vol*sqrt(ttm);

price = exp(-rf*ttm) * (K .* normcdf(-d2) - F .* normcdf(-d1));

delta = exp(-rf*ttm) * (normcdf(d1,0,1) - 1);
