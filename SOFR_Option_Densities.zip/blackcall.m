function [price delta gam vega] = blackcall(F, K, vol, ttm, rf)

d1 = (log(F./K) + (vol.^2/2).*ttm) ./ (vol.*sqrt(ttm));
d2 = d1 - vol.*sqrt(ttm);

price = exp(-rf.*ttm) .* (F .* normcdf(d1) - K .* normcdf(d2));

delta = exp(-rf.*ttm) .* normcdf(d1,0,1);

gam = exp(-rf.*ttm) .* normpdf(d1,0,1) ./ (F .* vol .* sqrt(ttm));

vega = exp(-rf.*ttm) .* F .* normpdf(d1,0,1) .* sqrt(ttm);
